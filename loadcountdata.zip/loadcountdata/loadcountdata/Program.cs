﻿using System;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector; // Thư viện kết nối CRM

namespace FixDataCountTool
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== TOOL CẬP NHẬT SỐ LƯỢNG CON (CONTACT) CHO CHA (ACCOUNT) ===");

            // 1. CẤU HÌNH KẾT NỐI
            // Bạn thay thông tin của bạn vào dòng bên dưới
            // UserName: Tài khoản đăng nhập CRM
            // Password: Mật khẩu
            // Url: Địa chỉ môi trường (Ví dụ: https://org12345.crm5.dynamics.com)
            //string connectionString = @"
            //    AuthType=OAuth;
            //    Url=https://org4536e97b.crm5.dynamics.com;
            //    UserName=phunh@hblabvn.onmicrosoft.com;
            //    Password=Phu001204036687@;
            //    AppId=51f81489-12ee-4a9e-aaae-a2591f45987d;
            //    RedirectUri=app://58145B91-0C36-4500-8554-080854F2AC97;";

            string connectionString = @"
                AuthType=OAuth;
                Url=https://org3c659c24.crm5.dynamics.com;
                UserName=phunh@hblabvn.onmicrosoft.com;
                Password=Phu001204036687@;
                AppId=51f81489-12ee-4a9e-aaae-a2591f45987d;
                RedirectUri=app://58145B91-0C36-4500-8554-080854F2AC97;";

            try
            {
                Console.WriteLine("Đang kết nối đến Dataverse...");
                CrmServiceClient service = new CrmServiceClient(connectionString);

                if (!service.IsReady)
                {
                    Console.WriteLine("Lỗi kết nối: " + service.LastCrmError);
                    Console.ReadLine();
                    return;
                }
                Console.WriteLine("Kết nối thành công! Đang lấy danh sách Account...");

                // 2. CẤU HÌNH TÊN BẢNG VÀ TRƯỜNG (Check kỹ đoạn này)
                string parentTable = "hbl_account";           // Bảng Cha
                string parentIdField = "hbl_accountid";       // ID bảng Cha
                string countField = "hbl_account_total_contacts"; // Trường lưu số lượng trên Cha

                string childTable = "hbl_contact";            // Bảng Con
                string childIdField = "hbl_contactid";        // ID bảng Con
                string lookupField = "hbl_contact_account";   // Lookup từ Con trỏ về Cha

                // 3. LẤY TẤT CẢ ACCOUNT CHA
                // (Lấy tối đa 5000 bản ghi - nếu nhiều hơn cần phân trang, nhưng tool chạy 1 lần thế này là ổn)
                QueryExpression query = new QueryExpression(parentTable);
                query.ColumnSet = new ColumnSet(parentIdField); // Chỉ cần lấy ID để tối ưu tốc độ

                // (Tùy chọn) Nếu chỉ muốn chạy cho Account đang hoạt động thì mở comment dòng dưới
                // query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

                EntityCollection parents = service.RetrieveMultiple(query);
                Console.WriteLine($"=> Tìm thấy {parents.Entities.Count} Account. Bắt đầu tính toán...");

                // 4. DUYỆT QUA TỪNG CHA ĐỂ TÍNH LẠI
                int processed = 0;
                foreach (var parent in parents.Entities)
                {
                    Guid parentId = parent.Id;

                    // Dùng FetchXML để đếm số lượng con (Nhanh hơn lấy hết con về đếm)
                    string fetchXml = $@"
                    <fetch distinct='false' mapping='logical' aggregate='true'>
                        <entity name='{childTable}'>
                            <attribute name='{childIdField}' alias='cnt' aggregate='count'/>
                            <filter>
                                <condition attribute='{lookupField}' operator='eq' value='{parentId}' />
                            </filter>
                        </entity>
                    </fetch>";

                    EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));

                    int count = 0;
                    if (result.Entities.Count > 0 && result.Entities[0].Contains("cnt"))
                    {
                        count = (int)((AliasedValue)result.Entities[0]["cnt"]).Value;
                    }

                    // Update lại vào Cha
                    Entity parentUpdate = new Entity(parentTable, parentId);
                    parentUpdate[countField] = count;
                    service.Update(parentUpdate);

                    processed++;
                    // In tiến độ ra màn hình cho đỡ sốt ruột
                    Console.WriteLine($"[{processed}/{parents.Entities.Count}] Updated ID {parentId} => Count: {count}");
                }

                Console.WriteLine("=== HOÀN TẤT CẬP NHẬT DỮ LIỆU ===");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Xảy ra lỗi: " + ex.Message);
            }

            Console.WriteLine("Bấm phím bất kỳ để thoát...");
            Console.ReadLine();
        }
    }
}